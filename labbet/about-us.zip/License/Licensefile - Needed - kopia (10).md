**LABBETS IBUA LICENSE AGREEMENT**

Website Ownership and Usage License



License ID: IBUA-WL97-A2F4-9C31-77B2

Certificate Serial: SSL-LAB-8842-19F7-AC55-2D91

Issued: 2026-03-13

Status: Active



Owner / Creator

Name: wille9799

Role: Original Creator and Legal Owner



**Ownership Notice**

This website, including all source code, design elements, systems, and associated files, has been created and is owned by wille9799. All rights, ownership, and intellectual property remain exclusively with the creator unless explicitly licensed in writing.



**License Type**

This project is distributed under the "Labbets IBUA License".



**Usage Restrictions**

The following actions are strictly prohibited without explicit written permission from the owner:



• Copying or redistributing the website or its source code

• Sharing licensed material publicly or privately

• Republishing, selling, or modifying the project for distribution

• Removing or altering this license file



Any unauthorized distribution, sharing, or replication of this material will be reported and may result in legal action.



**License File Requirement**

This LICENSE file must remain present and unchanged within the project directory.

Removal or modification of this file will invalidate the license and may cause the system or website to stop functioning properly.



**Integrity Verification**

License Hash: 7A3F-11C9-8D21-FF02-9C71-ACB4-55D1

Verification Token: WL9799-SECURE-LICENSE-AUTH



**Legal Notice**

By using, hosting, modifying, or accessing this project, you acknowledge that the website and all associated materials are protected under the Labbets IBUA License and owned by wille9799.



Violation of these terms will be documented and reported.



Copyright

© 2026 wille9799

All Rights Reserved.



